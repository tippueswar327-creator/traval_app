interface NatpacLogoProps {
  className?: string;
  variant?: 'full' | 'compact';
}

export function NatpacLogo({ className = "h-10", variant = 'full' }: NatpacLogoProps) {
  if (variant === 'compact') {
    return (
      <svg
        viewBox="0 0 120 40"
        className={className}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background */}
        <rect width="120" height="40" rx="8" fill="#2563EB" />
        
        {/* Road/Path Icon */}
        <g transform="translate(8, 8)">
          <path
            d="M4 12 L20 12 M12 4 L12 20 M8 8 L16 8 M8 16 L16 16"
            stroke="white"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
          <circle cx="6" cy="6" r="1" fill="white" />
          <circle cx="18" cy="6" r="1" fill="white" />
          <circle cx="6" cy="18" r="1" fill="white" />
          <circle cx="18" cy="18" r="1" fill="white" />
        </g>
        
        {/* Text */}
        <text
          x="36"
          y="16"
          fontSize="10"
          fontWeight="600"
          fill="white"
        >
          NATPAC
        </text>
        <text
          x="36"
          y="28"
          fontSize="6"
          fill="rgba(255,255,255,0.8)"
        >
          TRAVEL DATA
        </text>
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 200 40"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background */}
      <rect width="200" height="40" rx="8" fill="#2563EB" />
      
      {/* Road Network Icon */}
      <g transform="translate(8, 8)">
        {/* Main roads */}
        <path
          d="M4 12 L20 12 M12 4 L12 20 M8 8 L16 8 M8 16 L16 16"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        {/* Data points */}
        <circle cx="6" cy="6" r="1" fill="white" />
        <circle cx="18" cy="6" r="1" fill="white" />
        <circle cx="6" cy="18" r="1" fill="white" />
        <circle cx="18" cy="18" r="1" fill="white" />
        <circle cx="12" cy="12" r="1.5" fill="#FDE047" />
        
        {/* Connection lines */}
        <path
          d="M6 6 L12 12 M18 6 L12 12 M6 18 L12 12 M18 18 L12 12"
          stroke="rgba(255,255,255,0.3)"
          strokeWidth="0.5"
        />
      </g>
      
      {/* Text */}
      <text
        x="40"
        y="16"
        fontSize="12"
        fontWeight="700"
        fill="white"
      >
        NATPAC
      </text>
      <text
        x="40"
        y="28"
        fontSize="8"
        fill="rgba(255,255,255,0.9)"
      >
        TRAVEL DATA COLLECTION
      </text>
      
      {/* SIH Badge */}
      <g transform="translate(160, 6)">
        <rect width="32" height="16" rx="4" fill="white" />
        <text
          x="16"
          y="11"
          fontSize="6"
          fontWeight="600"
          fill="#2563EB"
          textAnchor="middle"
        >
          SIH 2025
        </text>
      </g>
      
      {/* Kerala Map Outline (simplified) */}
      <g transform="translate(115, 10)">
        <path
          d="M8 2 C10 1, 12 2, 14 4 C15 6, 14 8, 13 10 C12 12, 10 14, 8 16 C6 18, 4 16, 2 14 C1 12, 0 10, 1 8 C2 6, 4 4, 6 2 C7 1, 8 2, 8 2 Z"
          fill="rgba(255,255,255,0.2)"
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="0.5"
        />
        <circle cx="8" cy="9" r="1" fill="#FDE047" />
      </g>
    </svg>
  );
}