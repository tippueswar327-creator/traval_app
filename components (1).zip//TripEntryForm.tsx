import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { MapPin, Clock, Users, Route, Save } from 'lucide-react';
import { Badge } from './ui/badge';

interface TripData {
  tripNumber: string;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  travelMode: string;
  purpose: string;
  numberOfTravelers: string;
  additionalNotes: string;
}

interface TripEntryFormProps {
  onSubmit: (data: TripData) => void;
}

export function TripEntryForm({ onSubmit }: TripEntryFormProps) {
  const [formData, setFormData] = useState<TripData>({
    tripNumber: '',
    origin: '',
    destination: '',
    departureTime: '',
    arrivalTime: '',
    travelMode: '',
    purpose: '',
    numberOfTravelers: '1',
    additionalNotes: ''
  });

  const handleInputChange = (field: keyof TripData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const travelModes = [
    'Private Car',
    'Bus',
    'Train',
    'Flight',
    'Metro',
    'Auto Rickshaw',
    'Taxi/Cab',
    'Two Wheeler',
    'Walking',
    'Cycling',
    'Others'
  ];

  const tripPurposes = [
    'Work/Office',
    'Education',
    'Shopping',
    'Medical',
    'Recreation',
    'Social/Visit',
    'Business',
    'Others'
  ];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <Route className="h-5 w-5 text-blue-600" />
          Trip Information
        </CardTitle>
        <p className="text-muted-foreground">
          Please provide details about your journey for transportation planning research.
        </p>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tripNumber">Trip ID</Label>
              <Input
                id="tripNumber"
                value={formData.tripNumber}
                onChange={(e) => handleInputChange('tripNumber', e.target.value)}
                placeholder="Auto-generated"
                disabled
                className="bg-muted"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="numberOfTravelers" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Number of Travelers
              </Label>
              <Select
                value={formData.numberOfTravelers}
                onValueChange={(value) => handleInputChange('numberOfTravelers', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1,2,3,4,5,6,7,8,9,10].map(num => (
                    <SelectItem key={num} value={num.toString()}>
                      {num} {num === 1 ? 'Person' : 'People'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="origin" className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-green-600" />
                Origin (Starting Point)
              </Label>
              <Input
                id="origin"
                value={formData.origin}
                onChange={(e) => handleInputChange('origin', e.target.value)}
                placeholder="Enter your starting location"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="destination" className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-red-600" />
                Destination
              </Label>
              <Input
                id="destination"
                value={formData.destination}
                onChange={(e) => handleInputChange('destination', e.target.value)}
                placeholder="Enter your destination"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="departureTime" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Departure Time
              </Label>
              <Input
                id="departureTime"
                type="datetime-local"
                value={formData.departureTime}
                onChange={(e) => handleInputChange('departureTime', e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="arrivalTime">Expected Arrival Time</Label>
              <Input
                id="arrivalTime"
                type="datetime-local"
                value={formData.arrivalTime}
                onChange={(e) => handleInputChange('arrivalTime', e.target.value)}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Travel Mode</Label>
              <Select
                value={formData.travelMode}
                onValueChange={(value) => handleInputChange('travelMode', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select mode of transport" />
                </SelectTrigger>
                <SelectContent>
                  {travelModes.map(mode => (
                    <SelectItem key={mode} value={mode}>{mode}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Trip Purpose</Label>
              <Select
                value={formData.purpose}
                onValueChange={(value) => handleInputChange('purpose', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select trip purpose" />
                </SelectTrigger>
                <SelectContent>
                  {tripPurposes.map(purpose => (
                    <SelectItem key={purpose} value={purpose}>{purpose}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="additionalNotes">Additional Notes (Optional)</Label>
            <Textarea
              id="additionalNotes"
              value={formData.additionalNotes}
              onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
              placeholder="Any additional information about your trip..."
              rows={3}
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-1">
                <MapPin className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <h4 className="text-blue-900 mb-1">Data Usage Consent</h4>
                <p className="text-blue-700 text-sm">
                  Your travel data will be used by NATPAC scientists for transportation planning research. 
                  All data is anonymized and used solely for improving Kerala's transportation infrastructure.
                </p>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg">
            <Save className="h-4 w-4 mr-2" />
            Save Trip Data
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}