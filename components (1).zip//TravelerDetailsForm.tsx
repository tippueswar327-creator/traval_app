import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Plus, Trash2, Users, UserCheck } from 'lucide-react';

interface Traveler {
  id: string;
  ageGroup: string;
  gender: string;
  relation: string;
}

interface TravelerDetailsFormProps {
  numberOfTravelers: number;
  onComplete: (travelers: Traveler[]) => void;
  onBack: () => void;
}

export function TravelerDetailsForm({ numberOfTravelers, onComplete, onBack }: TravelerDetailsFormProps) {
  const [travelers, setTravelers] = useState<Traveler[]>([
    {
      id: '1',
      ageGroup: '',
      gender: '',
      relation: 'Self'
    }
  ]);

  const ageGroups = ['0-12', '13-18', '19-25', '26-35', '36-45', '46-60', '60+'];
  const relations = ['Self', 'Spouse', 'Child', 'Parent', 'Sibling', 'Friend', 'Colleague', 'Other'];

  const addTraveler = () => {
    if (travelers.length < numberOfTravelers) {
      setTravelers(prev => [...prev, {
        id: (prev.length + 1).toString(),
        ageGroup: '',
        gender: '',
        relation: ''
      }]);
    }
  };

  const removeTraveler = (id: string) => {
    if (travelers.length > 1) {
      setTravelers(prev => prev.filter(t => t.id !== id));
    }
  };

  const updateTraveler = (id: string, field: keyof Omit<Traveler, 'id'>, value: string) => {
    setTravelers(prev => prev.map(t => 
      t.id === id ? { ...t, [field]: value } : t
    ));
  };

  const handleComplete = () => {
    const isValid = travelers.every(t => t.ageGroup && t.gender && t.relation);
    if (isValid && travelers.length <= numberOfTravelers) {
      onComplete(travelers);
    }
  };

  const isFormValid = travelers.every(t => t.ageGroup && t.gender && t.relation) && 
                     travelers.length <= numberOfTravelers;

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5 text-blue-600" />
          Traveler Details
          <Badge variant="secondary">{travelers.length}/{numberOfTravelers}</Badge>
        </CardTitle>
        <p className="text-muted-foreground">
          Please provide basic demographic information for all travelers (no personal identifiers required).
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {travelers.map((traveler, index) => (
          <div key={traveler.id} className="p-4 border rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="flex items-center gap-2">
                <UserCheck className="h-4 w-4" />
                Traveler {index + 1}
                {index === 0 && <Badge variant="outline">Primary</Badge>}
              </h4>
              {travelers.length > 1 && index > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => removeTraveler(traveler.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Age Group</Label>
                <Select
                  value={traveler.ageGroup}
                  onValueChange={(value) => updateTraveler(traveler.id, 'ageGroup', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select age group" />
                  </SelectTrigger>
                  <SelectContent>
                    {ageGroups.map(age => (
                      <SelectItem key={age} value={age}>{age} years</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Gender</Label>
                <Select
                  value={traveler.gender}
                  onValueChange={(value) => updateTraveler(traveler.id, 'gender', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                    <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Relation to Primary</Label>
                <Select
                  value={traveler.relation}
                  onValueChange={(value) => updateTraveler(traveler.id, 'relation', value)}
                  disabled={index === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select relation" />
                  </SelectTrigger>
                  <SelectContent>
                    {relations.map(relation => (
                      <SelectItem key={relation} value={relation}>{relation}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        ))}

        {travelers.length < numberOfTravelers && (
          <Button 
            variant="outline" 
            onClick={addTraveler}
            className="w-full border-dashed"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Traveler ({travelers.length}/{numberOfTravelers})
          </Button>
        )}

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <h4 className="text-amber-900 mb-2">Privacy Notice</h4>
          <p className="text-amber-800 text-sm">
            This demographic information helps researchers understand travel patterns across different age groups and family compositions. 
            No personal identifying information is collected or stored.
          </p>
        </div>

        <div className="flex gap-3 pt-4">
          <Button variant="outline" onClick={onBack} className="flex-1">
            Back to Trip Details
          </Button>
          <Button 
            onClick={handleComplete}
            disabled={!isFormValid}
            className="flex-1"
          >
            Complete & Submit
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}