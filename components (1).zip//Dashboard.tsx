import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Plus, MapPin, Clock, Users, BarChart3, Database } from 'lucide-react';

interface DashboardProps {
  onNewTrip: () => void;
}

export function Dashboard({ onNewTrip }: DashboardProps) {
  const recentTrips = [
    {
      id: 'TRP001',
      origin: 'Kochi',
      destination: 'Thiruvananthapuram',
      mode: 'Train',
      time: '2 hours ago',
      status: 'completed'
    },
    {
      id: 'TRP002', 
      origin: 'Kozhikode',
      destination: 'Kochi',
      mode: 'Bus',
      time: '5 hours ago',
      status: 'completed'
    },
    {
      id: 'TRP003',
      origin: 'Thrissur',
      destination: 'Palakkad',
      mode: 'Private Car',
      time: '1 day ago',
      status: 'completed'
    }
  ];

  const stats = [
    { label: 'Total Trips', value: '156', icon: MapPin, color: 'bg-blue-500' },
    { label: 'This Week', value: '12', icon: Clock, color: 'bg-green-500' },
    { label: 'Contributors', value: '1.2K', icon: Users, color: 'bg-purple-500' },
    { label: 'Data Points', value: '45K', icon: Database, color: 'bg-orange-500' }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl mb-2">Travel Data Collection</h1>
        <p className="opacity-90 mb-4">
          Help improve Kerala's transportation planning by sharing your travel patterns.
        </p>
        <Button 
          onClick={onNewTrip}
          className="bg-white text-blue-600 hover:bg-gray-100"
          size="lg"
        >
          <Plus className="h-4 w-4 mr-2" />
          Record New Trip
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">{stat.label}</p>
                    <p className="text-2xl">{stat.value}</p>
                  </div>
                  <div className={`${stat.color} rounded-full p-2`}>
                    <Icon className="h-4 w-4 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recent Trips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Recent Trips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentTrips.map((trip) => (
              <div 
                key={trip.id} 
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted/80 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-blue-100 rounded-full p-2">
                    <MapPin className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">{trip.origin} → {trip.destination}</p>
                    <p className="text-sm text-muted-foreground">
                      {trip.mode} • {trip.time}
                    </p>
                  </div>
                </div>
                <Badge variant="secondary">{trip.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Information Section */}
      <Card>
        <CardHeader>
          <CardTitle>About This Initiative</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
                <Database className="h-4 w-4 text-green-600" />
              </div>
              <div>
                <h4>Data Collection Purpose</h4>
                <p className="text-muted-foreground text-sm">
                  NATPAC uses this data for transportation planning to improve Kerala's road infrastructure and public transport systems.
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                <Users className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <h4>Privacy & Security</h4>
                <p className="text-muted-foreground text-sm">
                  All personal data is anonymized. Only travel patterns and aggregated statistics are used for research purposes.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}