import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../services/trip_service.dart';
import '../utils/constants.dart';
import 'home/home_screen.dart';
import 'trips/trips_screen.dart';
import 'maps/map_screen.dart';
import 'profile/profile_screen.dart';
import 'trips/create_trip_screen.dart';

/// Main wrapper with bottom navigation and floating action button
class MainWrapper extends StatefulWidget {
  const MainWrapper({super.key});

  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  late PageController _pageController;
  late AnimationController _fabAnimationController;
  late Animation<double> _fabScaleAnimation;

  final List<BottomNavigationBarItem> _bottomNavItems = [
    const BottomNavigationBarItem(
      icon: Icon(Icons.home_outlined),
      activeIcon: Icon(Icons.home),
      label: 'Home',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.list_alt_outlined),
      activeIcon: Icon(Icons.list_alt),
      label: 'Trips',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.map_outlined),
      activeIcon: Icon(Icons.map),
      label: 'Map',
    ),
    const BottomNavigationBarItem(
      icon: Icon(Icons.person_outline),
      activeIcon: Icon(Icons.person),
      label: 'Profile',
    ),
  ];

  @override
  void initState() {
    super.initState();
    
    _pageController = PageController();
    
    // Initialize FAB animation
    _fabAnimationController = AnimationController(
      duration: AppAnimations.medium,
      vsync: this,
    );
    
    _fabScaleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fabAnimationController,
      curve: Curves.elasticOut,
    ));

    // Start FAB animation
    _fabAnimationController.forward();

    // Load user trips on app start
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadUserData();
    });
  }

  /// Load user data and trips
  void _loadUserData() {
    final authService = context.read<AuthService>();
    final tripService = context.read<TripService>();
    
    if (authService.user != null) {
      tripService.loadUserTrips(authService.user!.uid);
      tripService.loadCommunityTrips();
    }
  }

  /// Handle bottom navigation tap
  void _onBottomNavTap(int index) {
    setState(() {
      _currentIndex = index;
    });
    
    _pageController.animateToPage(
      index,
      duration: AppAnimations.medium,
      curve: Curves.easeInOut,
    );
  }

  /// Handle page view changes
  void _onPageChanged(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  /// Navigate to create trip screen
  void _navigateToCreateTrip() {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            const CreateTripScreen(),
        transitionDuration: AppAnimations.medium,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.0, 1.0),
              end: Offset.zero,
            ).animate(CurvedAnimation(
              parent: animation,
              curve: Curves.easeOut,
            )),
            child: FadeTransition(
              opacity: animation,
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fabAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        controller: _pageController,
        onPageChanged: _onPageChanged,
        children: const [
          HomeScreen(),
          TripsScreen(),
          MapScreen(),
          ProfileScreen(),
        ],
      ),
      
      // Premium floating action button with animation
      floatingActionButton: AnimatedBuilder(
        animation: _fabScaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _fabScaleAnimation.value,
            child: FloatingActionButton.extended(
              onPressed: _navigateToCreateTrip,
              icon: const Icon(Icons.add, size: AppDimensions.iconM),
              label: Text(
                'New Trip',
                style: AppTextStyles.button.copyWith(fontSize: 14),
              ),
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: Colors.white,
              elevation: 6,
              heroTag: "createTrip",
            ),
          );
        },
      ),
      
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      
      // Premium bottom navigation bar with custom styling
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomAppBar(
          height: 70,
          notchMargin: 8,
          color: Colors.white,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(_bottomNavItems.length, (index) {
              final isSelected = _currentIndex == index;
              final item = _bottomNavItems[index];
              
              return Expanded(
                child: InkWell(
                  onTap: () => _onBottomNavTap(index),
                  borderRadius: BorderRadius.circular(AppDimensions.radiusM),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: AppDimensions.paddingS,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Icon with color animation
                        AnimatedContainer(
                          duration: AppAnimations.fast,
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.primaryBlue.withOpacity(0.1)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            isSelected
                                ? (item.activeIcon as Icon).icon
                                : (item.icon as Icon).icon,
                            color: isSelected
                                ? AppColors.primaryBlue
                                : AppColors.textSecondary,
                            size: AppDimensions.iconM,
                          ),
                        ),
                        
                        const SizedBox(height: 2),
                        
                        // Label with color animation
                        AnimatedDefaultTextStyle(
                          duration: AppAnimations.fast,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: isSelected
                                ? FontWeight.w600
                                : FontWeight.w400,
                            color: isSelected
                                ? AppColors.primaryBlue
                                : AppColors.textSecondary,
                          ),
                          child: Text(item.label!),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}