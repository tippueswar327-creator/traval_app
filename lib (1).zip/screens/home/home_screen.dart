import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../services/auth_service.dart';
import '../../services/trip_service.dart';
import '../../utils/constants.dart';
import '../../widgets/premium_button.dart';
import '../../widgets/trip_card.dart';
import '../../widgets/stats_card.dart';
import '../../widgets/achievement_badge.dart';
import '../trips/create_trip_screen.dart';

/// Premium home screen with dashboard, quick stats, and recent trips
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.2, 1.0, curve: Curves.easeOut),
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(0.0, 0.8, curve: Curves.easeOut),
    ));
    
    _animationController.forward();
  }

  /// Navigate to create trip screen
  void _navigateToCreateTrip() {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            const CreateTripScreen(),
        transitionDuration: AppAnimations.medium,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.0, 1.0),
              end: Offset.zero,
            ).animate(animation),
            child: child,
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundGrey,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            final authService = context.read<AuthService>();
            final tripService = context.read<TripService>();
            
            if (authService.user != null) {
              await Future.wait([
                tripService.loadUserTrips(authService.user!.uid),
                tripService.loadCommunityTrips(),
              ]);
            }
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(AppDimensions.paddingM),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with welcome message
                SlideTransition(
                  position: _slideAnimation,
                  child: _buildHeader(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL),
                
                // Start new trip CTA
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildNewTripCTA(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL),
                
                // Quick stats
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildQuickStats(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL),
                
                // Last trip map preview
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildLastTripPreview(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL),
                
                // Recent trips
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildRecentTrips(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL),
                
                // Achievements
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: _buildAchievements(),
                ),
                
                const SizedBox(height: AppDimensions.paddingXL * 2),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Build header with welcome message and user info
  Widget _buildHeader() {
    return Consumer<AuthService>(
      builder: (context, authService, child) {
        final user = authService.userModel;
        final displayName = user?.displayName ?? 'Traveler';
        
        return Row(
          children: [
            // User avatar
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryBlue.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: user?.photoUrl != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        user!.photoUrl!,
                        fit: BoxFit.cover,
                      ),
                    )
                  : const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 30,
                    ),
            ),
            
            const SizedBox(width: AppDimensions.paddingM),
            
            // Welcome text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Welcome back,',
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                  Text(
                    displayName,
                    style: AppTextStyles.headline2,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (user != null) ...[
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.accentGreen.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        user.levelTitle,
                        style: AppTextStyles.caption.copyWith(
                          color: AppColors.accentGreen,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            
            // Notification icon
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(
                Icons.notifications_outlined,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        );
      },
    );
  }

  /// Build new trip CTA section
  Widget _buildNewTripCTA() {
    return Container(
      padding: const EdgeInsets.all(AppDimensions.paddingXL),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(AppDimensions.radiusXL),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryBlue.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(
                  Icons.add_location,
                  color: Colors.white,
                  size: 24,
                ),
              ),
              const SizedBox(width: AppDimensions.paddingM),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Start Your Next Adventure',
                      style: AppTextStyles.headline3.copyWith(
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Plan and track your journey with ease',
                      style: AppTextStyles.bodyMedium.copyWith(
                        color: Colors.white.withOpacity(0.9),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: AppDimensions.paddingL),
          
          PremiumButton(
            onPressed: _navigateToCreateTrip,
            backgroundColor: Colors.white,
            foregroundColor: AppColors.primaryBlue,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.add, size: 20),
                const SizedBox(width: 8),
                Text(
                  'Start New Trip',
                  style: AppTextStyles.button.copyWith(
                    color: AppColors.primaryBlue,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Build quick stats section
  Widget _buildQuickStats() {
    return Consumer<AuthService>(
      builder: (context, authService, child) {
        final user = authService.userModel;
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Journey Stats',
              style: AppTextStyles.headline3,
            ),
            
            const SizedBox(height: AppDimensions.paddingM),
            
            Row(
              children: [
                Expanded(
                  child: StatsCard(
                    icon: Icons.location_on,
                    iconColor: AppColors.primaryBlue,
                    title: 'Total Trips',
                    value: '${user?.totalTrips ?? 0}',
                  ),
                ),
                
                const SizedBox(width: AppDimensions.paddingM),
                
                Expanded(
                  child: StatsCard(
                    icon: Icons.straighten,
                    iconColor: AppColors.accentGreen,
                    title: 'Distance',
                    value: '${(user?.totalDistance ?? 0).toStringAsFixed(0)} km',
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: AppDimensions.paddingM),
            
            Row(
              children: [
                Expanded(
                  child: StatsCard(
                    icon: Icons.favorite,
                    iconColor: AppColors.error,
                    title: 'Likes Received',
                    value: '${user?.stats.communityLikes ?? 0}',
                  ),
                ),
                
                const SizedBox(width: AppDimensions.paddingM),
                
                Expanded(
                  child: StatsCard(
                    icon: Icons.share,
                    iconColor: AppColors.warning,
                    title: 'Shared Trips',
                    value: '${user?.stats.sharedTrips ?? 0}',
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  /// Build last trip map preview
  Widget _buildLastTripPreview() {
    return Consumer<TripService>(
      builder: (context, tripService, child) {
        final lastTrip = tripService.userTrips.isNotEmpty
            ? tripService.userTrips.first
            : null;
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Last Trip Overview',
                  style: AppTextStyles.headline3,
                ),
                if (lastTrip != null)
                  TextButton(
                    onPressed: () {
                      // Navigate to trip details
                    },
                    child: Text(
                      'View Details',
                      style: AppTextStyles.bodyMedium.copyWith(
                        color: AppColors.primaryBlue,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            ),
            
            const SizedBox(height: AppDimensions.paddingM),
            
            if (lastTrip != null)
              Container(
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppDimensions.radiusL),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(AppDimensions.radiusL),
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: lastTrip.startLocation,
                      zoom: 12,
                    ),
                    markers: {
                      Marker(
                        markerId: const MarkerId('start'),
                        position: lastTrip.startLocation,
                        icon: BitmapDescriptor.defaultMarkerWithHue(
                          BitmapDescriptor.hueGreen,
                        ),
                      ),
                      if (lastTrip.endLocation != null)
                        Marker(
                          markerId: const MarkerId('end'),
                          position: lastTrip.endLocation!,
                          icon: BitmapDescriptor.defaultMarkerWithHue(
                            BitmapDescriptor.hueRed,
                          ),
                        ),
                    },
                    zoomControlsEnabled: false,
                    myLocationButtonEnabled: false,
                    onMapCreated: (GoogleMapController controller) {
                      // Map created callback
                    },
                  ),
                ),
              )
            else
              Container(
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(AppDimensions.radiusL),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.map_outlined,
                        size: 48,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: AppDimensions.paddingM),
                      Text(
                        'No trips yet',
                        style: AppTextStyles.bodyLarge.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                      Text(
                        'Start your first adventure!',
                        style: AppTextStyles.bodyMedium.copyWith(
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  /// Build recent trips section
  Widget _buildRecentTrips() {
    return Consumer<TripService>(
      builder: (context, tripService, child) {
        final recentTrips = tripService.userTrips.take(3).toList();
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Recent Trips',
                  style: AppTextStyles.headline3,
                ),
                TextButton(
                  onPressed: () {
                    // Navigate to trips screen
                  },
                  child: Text(
                    'View All',
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.primaryBlue,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: AppDimensions.paddingM),
            
            if (recentTrips.isNotEmpty)
              ...recentTrips.map((trip) => Padding(
                padding: const EdgeInsets.only(bottom: AppDimensions.paddingM),
                child: TripCard(trip: trip),
              ))
            else
              Container(
                padding: const EdgeInsets.all(AppDimensions.paddingXL),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppDimensions.radiusL),
                ),
                child: Center(
                  child: Column(
                    children: [
                      Icon(
                        Icons.luggage_outlined,
                        size: 48,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: AppDimensions.paddingM),
                      Text(
                        'No trips yet',
                        style: AppTextStyles.bodyLarge.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                      Text(
                        'Create your first trip to get started!',
                        style: AppTextStyles.bodyMedium.copyWith(
                          color: Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  /// Build achievements section
  Widget _buildAchievements() {
    return Consumer<AuthService>(
      builder: (context, authService, child) {
        final user = authService.userModel;
        final userAchievements = user?.achievements ?? {};
        
        final earnedAchievements = userAchievements.entries
            .where((entry) => entry.value)
            .map((entry) => entry.key)
            .take(3)
            .toList();
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Achievements',
              style: AppTextStyles.headline3,
            ),
            
            const SizedBox(height: AppDimensions.paddingM),
            
            if (earnedAchievements.isNotEmpty)
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: earnedAchievements
                      .map((achievementKey) => Padding(
                        padding: const EdgeInsets.only(
                          right: AppDimensions.paddingM,
                        ),
                        child: AchievementBadge(
                          achievementKey: achievementKey,
                        ),
                      ))
                      .toList(),
                ),
              )
            else
              Container(
                padding: const EdgeInsets.all(AppDimensions.paddingL),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppDimensions.radiusL),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.emoji_events_outlined,
                      color: Colors.grey[400],
                      size: 32,
                    ),
                    const SizedBox(width: AppDimensions.paddingM),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'No achievements yet',
                            style: AppTextStyles.bodyLarge.copyWith(
                              color: Colors.grey[600],
                            ),
                          ),
                          Text(
                            'Complete trips to earn badges!',
                            style: AppTextStyles.bodyMedium.copyWith(
                              color: Colors.grey[500],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }
}