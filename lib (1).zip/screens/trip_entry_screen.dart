import 'package:flutter/material.dart';
import '../models/trip_data.dart';

class TripEntryScreen extends StatefulWidget {
  final Function(TripData) onSubmit;

  const TripEntryScreen({super.key, required this.onSubmit});

  @override
  State<TripEntryScreen> createState() => _TripEntryScreenState();
}

class _TripEntryScreenState extends State<TripEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _originController = TextEditingController();
  final _destinationController = TextEditingController();
  final _notesController = TextEditingController();
  
  DateTime? _departureTime;
  DateTime? _arrivalTime;
  String _travelMode = '';
  String _purpose = '';
  int _numberOfTravelers = 1;

  final List<String> _travelModes = [
    'Private Car',
    'Bus',
    'Train',
    'Metro',
    'Flight',
    'Auto Rickshaw',
    'Taxi/Cab',
    'Two Wheeler',
    'Walking',
    'Cycling',
    'Others'
  ];

  final List<String> _tripPurposes = [
    'Work/Office',
    'Education',
    'Shopping',
    'Medical',
    'Recreation',
    'Social/Visit',
    'Business',
    'Others'
  ];

  @override
  void dispose() {
    _originController.dispose();
    _destinationController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final tripData = TripData(
        tripNumber: '',
        origin: _originController.text,
        destination: _destinationController.text,
        departureTime: _departureTime,
        arrivalTime: _arrivalTime,
        travelMode: _travelMode,
        purpose: _purpose,
        numberOfTravelers: _numberOfTravelers,
        additionalNotes: _notesController.text,
      );
      widget.onSubmit(tripData);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 24),
                _buildTripIdAndTravelersRow(),
                const SizedBox(height: 24),
                _buildLocationFields(),
                const SizedBox(height: 24),
                _buildTimeFields(),
                const SizedBox(height: 24),
                _buildModeAndPurposeRow(),
                const SizedBox(height: 24),
                _buildNotesField(),
                const SizedBox(height: 24),
                _buildConsentSection(),
                const SizedBox(height: 24),
                _buildSubmitButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.route, color: Color(0xFF2563EB)),
            SizedBox(width: 8),
            Text(
              'Trip Information',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Please provide details about your journey for transportation planning research.',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildTripIdAndTravelersRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 600) {
          return Row(
            children: [
              Expanded(child: _buildTripIdField()),
              const SizedBox(width: 16),
              Expanded(child: _buildTravelersField()),
            ],
          );
        } else {
          return Column(
            children: [
              _buildTripIdField(),
              const SizedBox(height: 16),
              _buildTravelersField(),
            ],
          );
        }
      },
    );
  }

  Widget _buildTripIdField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Trip ID', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        TextFormField(
          initialValue: 'Auto-generated',
          enabled: false,
          decoration: const InputDecoration(
            fillColor: Color(0xFFF5F5F5),
          ),
        ),
      ],
    );
  }

  Widget _buildTravelersField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.people, size: 16),
            SizedBox(width: 4),
            Text('Number of Travelers', style: TextStyle(fontWeight: FontWeight.medium)),
          ],
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<int>(
          value: _numberOfTravelers,
          decoration: const InputDecoration(),
          items: List.generate(10, (index) => index + 1)
              .map((num) => DropdownMenuItem(
                    value: num,
                    child: Text('$num ${num == 1 ? 'Person' : 'People'}'),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _numberOfTravelers = value ?? 1;
            });
          },
        ),
      ],
    );
  }

  Widget _buildLocationFields() {
    return Column(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.location_on, size: 16, color: Colors.green),
                SizedBox(width: 4),
                Text('Origin (Starting Point)', style: TextStyle(fontWeight: FontWeight.medium)),
              ],
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _originController,
              decoration: const InputDecoration(
                hintText: 'Enter your starting location',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter origin';
                }
                return null;
              },
            ),
          ],
        ),
        const SizedBox(height: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.location_on, size: 16, color: Colors.red),
                SizedBox(width: 4),
                Text('Destination', style: TextStyle(fontWeight: FontWeight.medium)),
              ],
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _destinationController,
              decoration: const InputDecoration(
                hintText: 'Enter your destination',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter destination';
                }
                return null;
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTimeFields() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 600) {
          return Row(
            children: [
              Expanded(child: _buildDepartureTimeField()),
              const SizedBox(width: 16),
              Expanded(child: _buildArrivalTimeField()),
            ],
          );
        } else {
          return Column(
            children: [
              _buildDepartureTimeField(),
              const SizedBox(height: 16),
              _buildArrivalTimeField(),
            ],
          );
        }
      },
    );
  }

  Widget _buildDepartureTimeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.access_time, size: 16),
            SizedBox(width: 4),
            Text('Departure Time', style: TextStyle(fontWeight: FontWeight.medium)),
          ],
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: () async {
            final date = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime.now().subtract(const Duration(days: 7)),
              lastDate: DateTime.now().add(const Duration(days: 30)),
            );
            if (date != null && mounted) {
              final time = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (time != null) {
                setState(() {
                  _departureTime = DateTime(
                    date.year,
                    date.month,
                    date.day,
                    time.hour,
                    time.minute,
                  );
                });
              }
            }
          },
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
              color: const Color(0xFFF3F3F5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _departureTime != null
                      ? '${_departureTime!.day}/${_departureTime!.month}/${_departureTime!.year} ${_departureTime!.hour}:${_departureTime!.minute.toString().padLeft(2, '0')}'
                      : 'Select departure time',
                  style: TextStyle(
                    color: _departureTime != null ? Colors.black : Colors.grey[600],
                  ),
                ),
                const Icon(Icons.calendar_today, size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildArrivalTimeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Expected Arrival Time', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        InkWell(
          onTap: () async {
            final date = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime.now().subtract(const Duration(days: 7)),
              lastDate: DateTime.now().add(const Duration(days: 30)),
            );
            if (date != null && mounted) {
              final time = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (time != null) {
                setState(() {
                  _arrivalTime = DateTime(
                    date.year,
                    date.month,
                    date.day,
                    time.hour,
                    time.minute,
                  );
                });
              }
            }
          },
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
              color: const Color(0xFFF3F3F5),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _arrivalTime != null
                      ? '${_arrivalTime!.day}/${_arrivalTime!.month}/${_arrivalTime!.year} ${_arrivalTime!.hour}:${_arrivalTime!.minute.toString().padLeft(2, '0')}'
                      : 'Select arrival time (optional)',
                  style: TextStyle(
                    color: _arrivalTime != null ? Colors.black : Colors.grey[600],
                  ),
                ),
                const Icon(Icons.calendar_today, size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildModeAndPurposeRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 600) {
          return Row(
            children: [
              Expanded(child: _buildTravelModeField()),
              const SizedBox(width: 16),
              Expanded(child: _buildPurposeField()),
            ],
          );
        } else {
          return Column(
            children: [
              _buildTravelModeField(),
              const SizedBox(height: 16),
              _buildPurposeField(),
            ],
          );
        }
      },
    );
  }

  Widget _buildTravelModeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Travel Mode', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _travelMode.isEmpty ? null : _travelMode,
          decoration: const InputDecoration(
            hintText: 'Select mode of transport',
          ),
          items: _travelModes
              .map((mode) => DropdownMenuItem(
                    value: mode,
                    child: Text(mode),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _travelMode = value ?? '';
            });
          },
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please select travel mode';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildPurposeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Trip Purpose', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _purpose.isEmpty ? null : _purpose,
          decoration: const InputDecoration(
            hintText: 'Select trip purpose',
          ),
          items: _tripPurposes
              .map((purpose) => DropdownMenuItem(
                    value: purpose,
                    child: Text(purpose),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _purpose = value ?? '';
            });
          },
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please select trip purpose';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildNotesField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Additional Notes (Optional)', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        TextFormField(
          controller: _notesController,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Any additional information about your trip...',
          ),
        ),
      ],
    );
  }

  Widget _buildConsentSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFDCECFF),
        border: Border.all(color: const Color(0xFF93C5FD)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xFFBFDBFE),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.location_on,
              color: Color(0xFF2563EB),
              size: 16,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Data Usage Consent',
                  style: TextStyle(
                    fontWeight: FontWeight.medium,
                    color: Color(0xFF1E40AF),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Your travel data will be used by NATPAC scientists for transportation planning research. All data is anonymized and used solely for improving Kerala\'s transportation infrastructure.',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.blue[700],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmitButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: _submitForm,
        icon: const Icon(Icons.save),
        label: const Text('Save Trip Data'),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }
}