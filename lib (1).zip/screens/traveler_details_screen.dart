import 'package:flutter/material.dart';
import '../models/trip_data.dart';

class TravelerDetailsScreen extends StatefulWidget {
  final int numberOfTravelers;
  final Function(List<Traveler>) onComplete;
  final VoidCallback onBack;

  const TravelerDetailsScreen({
    super.key,
    required this.numberOfTravelers,
    required this.onComplete,
    required this.onBack,
  });

  @override
  State<TravelerDetailsScreen> createState() => _TravelerDetailsScreenState();
}

class _TravelerDetailsScreenState extends State<TravelerDetailsScreen> {
  List<Traveler> _travelers = [];

  final List<String> _ageGroups = ['0-12', '13-18', '19-25', '26-35', '36-45', '46-60', '60+'];
  final List<String> _relations = ['Self', 'Spouse', 'Child', 'Parent', 'Sibling', 'Friend', 'Colleague', 'Other'];
  final List<String> _genders = ['Male', 'Female', 'Other', 'Prefer not to say'];

  @override
  void initState() {
    super.initState();
    _travelers = [
      Traveler(
        id: '1',
        ageGroup: '',
        gender: '',
        relation: 'Self',
      )
    ];
  }

  void _addTraveler() {
    if (_travelers.length < widget.numberOfTravelers) {
      setState(() {
        _travelers.add(Traveler(
          id: (_travelers.length + 1).toString(),
          ageGroup: '',
          gender: '',
          relation: '',
        ));
      });
    }
  }

  void _removeTraveler(String id) {
    if (_travelers.length > 1) {
      setState(() {
        _travelers.removeWhere((t) => t.id == id);
      });
    }
  }

  void _updateTraveler(String id, String field, String value) {
    setState(() {
      final index = _travelers.indexWhere((t) => t.id == id);
      if (index != -1) {
        switch (field) {
          case 'ageGroup':
            _travelers[index] = _travelers[index].copyWith(ageGroup: value);
            break;
          case 'gender':
            _travelers[index] = _travelers[index].copyWith(gender: value);
            break;
          case 'relation':
            _travelers[index] = _travelers[index].copyWith(relation: value);
            break;
        }
      }
    });
  }

  bool get _isFormValid {
    return _travelers.every((t) => t.ageGroup.isNotEmpty && t.gender.isNotEmpty && t.relation.isNotEmpty) &&
           _travelers.length <= widget.numberOfTravelers;
  }

  void _handleComplete() {
    if (_isFormValid) {
      widget.onComplete(_travelers);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              ..._travelers.asMap().entries.map((entry) {
                final index = entry.key;
                final traveler = entry.value;
                return _buildTravelerCard(traveler, index);
              }),
              if (_travelers.length < widget.numberOfTravelers) ...[
                const SizedBox(height: 16),
                _buildAddTravelerButton(),
              ],
              const SizedBox(height: 24),
              _buildPrivacyNotice(),
              const SizedBox(height: 24),
              _buildActionButtons(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.people, color: Color(0xFF2563EB)),
            const SizedBox(width: 8),
            const Text(
              'Traveler Details',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '${_travelers.length}/${widget.numberOfTravelers}',
                style: const TextStyle(fontSize: 12),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Please provide basic demographic information for all travelers (no personal identifiers required).',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildTravelerCard(Traveler traveler, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.person_outline, size: 16),
                  const SizedBox(width: 4),
                  Text(
                    'Traveler ${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.medium),
                  ),
                  if (index == 0) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey[400]!),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'Primary',
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                  ],
                ],
              ),
              if (_travelers.length > 1 && index > 0)
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () => _removeTraveler(traveler.id),
                  iconSize: 20,
                ),
            ],
          ),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth > 600) {
                return Row(
                  children: [
                    Expanded(child: _buildAgeGroupField(traveler)),
                    const SizedBox(width: 16),
                    Expanded(child: _buildGenderField(traveler)),
                    const SizedBox(width: 16),
                    Expanded(child: _buildRelationField(traveler, index)),
                  ],
                );
              } else {
                return Column(
                  children: [
                    _buildAgeGroupField(traveler),
                    const SizedBox(height: 16),
                    _buildGenderField(traveler),
                    const SizedBox(height: 16),
                    _buildRelationField(traveler, index),
                  ],
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAgeGroupField(Traveler traveler) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Age Group', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: traveler.ageGroup.isEmpty ? null : traveler.ageGroup,
          decoration: const InputDecoration(
            hintText: 'Select age group',
          ),
          items: _ageGroups
              .map((age) => DropdownMenuItem(
                    value: age,
                    child: Text('$age years'),
                  ))
              .toList(),
          onChanged: (value) {
            _updateTraveler(traveler.id, 'ageGroup', value ?? '');
          },
        ),
      ],
    );
  }

  Widget _buildGenderField(Traveler traveler) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Gender', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: traveler.gender.isEmpty ? null : traveler.gender,
          decoration: const InputDecoration(
            hintText: 'Select gender',
          ),
          items: _genders
              .map((gender) => DropdownMenuItem(
                    value: gender.toLowerCase().replaceAll(' ', '-'),
                    child: Text(gender),
                  ))
              .toList(),
          onChanged: (value) {
            _updateTraveler(traveler.id, 'gender', value ?? '');
          },
        ),
      ],
    );
  }

  Widget _buildRelationField(Traveler traveler, int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Relation to Primary', style: TextStyle(fontWeight: FontWeight.medium)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: traveler.relation.isEmpty ? null : traveler.relation,
          decoration: const InputDecoration(
            hintText: 'Select relation',
          ),
          items: _relations
              .map((relation) => DropdownMenuItem(
                    value: relation,
                    child: Text(relation),
                  ))
              .toList(),
          onChanged: index == 0
              ? null
              : (value) {
                  _updateTraveler(traveler.id, 'relation', value ?? '');
                },
        ),
      ],
    );
  }

  Widget _buildAddTravelerButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _addTraveler,
        icon: const Icon(Icons.add),
        label: Text('Add Traveler (${_travelers.length}/${widget.numberOfTravelers})'),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: Colors.grey[400]!, style: BorderStyle.solid),
          padding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }

  Widget _buildPrivacyNotice() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFEF3C7),
        border: Border.all(color: const Color(0xFFE0E7FF)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Privacy Notice',
            style: TextStyle(
              fontWeight: FontWeight.medium,
              color: Color(0xFF92400E),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'This demographic information helps researchers understand travel patterns across different age groups and family compositions. No personal identifying information is collected or stored.',
            style: TextStyle(
              fontSize: 12,
              color: Colors.amber[800],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: widget.onBack,
            child: const Text('Back to Trip Details'),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton(
            onPressed: _isFormValid ? _handleComplete : null,
            child: const Text('Complete & Submit'),
          ),
        ),
      ],
    );
  }
}