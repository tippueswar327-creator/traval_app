import 'package:flutter/material.dart';
import '../models/trip_data.dart';
import '../widgets/app_header.dart';
import 'dashboard_screen.dart';
import 'trip_entry_screen.dart';
import 'traveler_details_screen.dart';
import 'success_screen.dart';

enum AppScreenType { dashboard, tripForm, travelerForm, success }

class AppScreen extends StatefulWidget {
  const AppScreen({super.key});

  @override
  State<AppScreen> createState() => _AppScreenState();
}

class _AppScreenState extends State<AppScreen> {
  AppScreenType _currentScreen = AppScreenType.dashboard;
  TripData? _tripData;
  List<Traveler> _travelerData = [];

  void _navigateToTripForm() {
    setState(() {
      _currentScreen = AppScreenType.tripForm;
    });
  }

  void _handleTripSubmit(TripData data) {
    final tripNumber = 'TRP${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    final tripWithId = data.copyWith(tripNumber: tripNumber);
    
    setState(() {
      _tripData = tripWithId;
    });
    
    if (data.numberOfTravelers == 1) {
      setState(() {
        _travelerData = [
          Traveler(
            id: '1',
            ageGroup: 'Not specified',
            gender: 'Not specified',
            relation: 'Self',
          )
        ];
        _currentScreen = AppScreenType.success;
      });
    } else {
      setState(() {
        _currentScreen = AppScreenType.travelerForm;
      });
    }
  }

  void _handleTravelerComplete(List<Traveler> travelers) {
    setState(() {
      _travelerData = travelers;
      _currentScreen = AppScreenType.success;
    });
  }

  void _handleBackToDashboard() {
    setState(() {
      _currentScreen = AppScreenType.dashboard;
      _tripData = null;
      _travelerData = [];
    });
  }

  void _handleBackToTripForm() {
    setState(() {
      _currentScreen = AppScreenType.tripForm;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const AppHeader(),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: _buildCurrentScreen(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentScreen() {
    switch (_currentScreen) {
      case AppScreenType.dashboard:
        return DashboardScreen(onNewTrip: _navigateToTripForm);
      case AppScreenType.tripForm:
        return TripEntryScreen(onSubmit: _handleTripSubmit);
      case AppScreenType.travelerForm:
        return TravelerDetailsScreen(
          numberOfTravelers: _tripData?.numberOfTravelers ?? 1,
          onComplete: _handleTravelerComplete,
          onBack: _handleBackToTripForm,
        );
      case AppScreenType.success:
        return SuccessScreen(
          tripData: _tripData,
          onBackToDashboard: _handleBackToDashboard,
        );
    }
  }
}