import 'package:flutter/material.dart';

/// Application constants including colors, dimensions, and configuration
class AppColors {
  // Primary brand colors as specified
  static const Color primaryBlue = Color(0xFF1976D2);
  static const Color accentGreen = Color(0xFF43A047);
  
  // Background colors
  static const Color backgroundWhite = Color(0xFFFFFFFF);
  static const Color backgroundGrey = Color(0xFFF8F9FA);
  static const Color backgroundCard = Color(0xFFFFFFFF);
  
  // Text colors
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF666666);
  static const Color textHint = Color(0xFF999999);
  
  // Status colors
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  
  // Gradient colors
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryBlue, Color(0xFF1565C0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient accentGradient = LinearGradient(
    colors: [accentGreen, Color(0xFF388E3C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

/// Dimension constants for consistent spacing
class AppDimensions {
  // Padding and margins
  static const double paddingXS = 4.0;
  static const double paddingS = 8.0;
  static const double paddingM = 16.0;
  static const double paddingL = 24.0;
  static const double paddingXL = 32.0;
  
  // Border radius
  static const double radiusS = 8.0;
  static const double radiusM = 12.0;
  static const double radiusL = 16.0;
  static const double radiusXL = 24.0;
  
  // Icon sizes
  static const double iconS = 16.0;
  static const double iconM = 24.0;
  static const double iconL = 32.0;
  static const double iconXL = 48.0;
  
  // Button heights
  static const double buttonHeight = 48.0;
  static const double buttonHeightL = 56.0;
}

/// Text style constants using Poppins font family
class AppTextStyles {
  static const TextStyle headline1 = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle headline2 = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle headline3 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: AppColors.textSecondary,
  );
  
  static const TextStyle button = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    color: Colors.white,
  );
  
  static const TextStyle caption = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.w400,
    color: AppColors.textHint,
  );
}

/// Animation duration constants
class AppAnimations {
  static const Duration fast = Duration(milliseconds: 200);
  static const Duration medium = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 500);
}

/// App configuration constants
class AppConfig {
  static const String appName = 'TravelLog';
  static const String appVersion = '1.0.0';
  
  // API endpoints (replace with your actual endpoints)
  static const String baseUrl = 'https://api.travellog.com';
  static const String googleMapsApiKey = 'YOUR_GOOGLE_MAPS_API_KEY';
  
  // Firebase collection names
  static const String usersCollection = 'users';
  static const String tripsCollection = 'trips';
  static const String communityCollection = 'community';
  
  // Local storage keys
  static const String offlineTripsBox = 'offline_trips';
  static const String userPrefsBox = 'user_preferences';
  
  // Achievement thresholds
  static const int travelerBadgeKm = 100;
  static const int explorerBadgeKm = 500;
  static const int adventurerBadgeKm = 1000;
}

/// Badge/Achievement definitions
class Achievements {
  static const Map<String, Map<String, dynamic>> badges = {
    'first_trip': {
      'title': 'First Journey',
      'description': 'Completed your first trip',
      'icon': '🎯',
      'color': AppColors.accentGreen,
    },
    'traveler_100km': {
      'title': '100 KM Traveler',
      'description': 'Traveled 100+ kilometers',
      'icon': '🚗',
      'color': AppColors.primaryBlue,
    },
    'explorer_500km': {
      'title': 'Explorer',
      'description': 'Traveled 500+ kilometers',
      'icon': '🗺️',
      'color': AppColors.warning,
    },
    'adventurer_1000km': {
      'title': 'Adventurer',
      'description': 'Traveled 1000+ kilometers',
      'icon': '⭐',
      'color': AppColors.error,
    },
    'community_star': {
      'title': 'Community Star',
      'description': 'Received 50+ likes on shared trips',
      'icon': '💫',
      'color': AppColors.accentGreen,
    },
  };
}