import 'package:cloud_firestore/cloud_firestore.dart';

/// User model for managing user data and profile information
class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? photoUrl;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, bool> achievements;
  final int totalTrips;
  final double totalDistance;
  final List<String> favoriteDestinations;
  final UserStats stats;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.photoUrl,
    required this.createdAt,
    required this.updatedAt,
    this.achievements = const {},
    this.totalTrips = 0,
    this.totalDistance = 0.0,
    this.favoriteDestinations = const [],
    required this.stats,
  });

  /// Create UserModel from Firestore document
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return UserModel(
      id: doc.id,
      email: data['email'] ?? '',
      displayName: data['displayName'] ?? '',
      photoUrl: data['photoUrl'],
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
      achievements: Map<String, bool>.from(data['achievements'] ?? {}),
      totalTrips: data['totalTrips'] ?? 0,
      totalDistance: (data['totalDistance'] ?? 0.0).toDouble(),
      favoriteDestinations: List<String>.from(data['favoriteDestinations'] ?? []),
      stats: UserStats.fromMap(data['stats'] ?? {}),
    );
  }

  /// Convert UserModel to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'displayName': displayName,
      'photoUrl': photoUrl,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'achievements': achievements,
      'totalTrips': totalTrips,
      'totalDistance': totalDistance,
      'favoriteDestinations': favoriteDestinations,
      'stats': stats.toMap(),
    };
  }

  /// Create a copy of UserModel with updated fields
  UserModel copyWith({
    String? email,
    String? displayName,
    String? photoUrl,
    DateTime? updatedAt,
    Map<String, bool>? achievements,
    int? totalTrips,
    double? totalDistance,
    List<String>? favoriteDestinations,
    UserStats? stats,
  }) {
    return UserModel(
      id: id,
      email: email ?? this.email,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      achievements: achievements ?? this.achievements,
      totalTrips: totalTrips ?? this.totalTrips,
      totalDistance: totalDistance ?? this.totalDistance,
      favoriteDestinations: favoriteDestinations ?? this.favoriteDestinations,
      stats: stats ?? this.stats,
    );
  }

  /// Check if user has a specific achievement
  bool hasAchievement(String achievementKey) {
    return achievements[achievementKey] ?? false;
  }

  /// Get user's current level based on total distance
  int get userLevel {
    if (totalDistance >= 1000) return 4; // Adventurer
    if (totalDistance >= 500) return 3;  // Explorer
    if (totalDistance >= 100) return 2;  // Traveler
    if (totalTrips >= 1) return 1;       // Beginner
    return 0; // New user
  }

  /// Get user's level title
  String get levelTitle {
    switch (userLevel) {
      case 4: return 'Adventurer';
      case 3: return 'Explorer';
      case 2: return 'Traveler';
      case 1: return 'Beginner';
      default: return 'New User';
    }
  }
}

/// User statistics model
class UserStats {
  final int tripsThisMonth;
  final int tripsThisYear;
  final double distanceThisMonth;
  final double distanceThisYear;
  final int communityLikes;
  final int sharedTrips;
  final String favoriteTransportMode;
  final List<String> visitedCountries;
  final List<String> visitedStates;

  UserStats({
    this.tripsThisMonth = 0,
    this.tripsThisYear = 0,
    this.distanceThisMonth = 0.0,
    this.distanceThisYear = 0.0,
    this.communityLikes = 0,
    this.sharedTrips = 0,
    this.favoriteTransportMode = '',
    this.visitedCountries = const [],
    this.visitedStates = const [],
  });

  /// Create UserStats from map
  factory UserStats.fromMap(Map<String, dynamic> map) {
    return UserStats(
      tripsThisMonth: map['tripsThisMonth'] ?? 0,
      tripsThisYear: map['tripsThisYear'] ?? 0,
      distanceThisMonth: (map['distanceThisMonth'] ?? 0.0).toDouble(),
      distanceThisYear: (map['distanceThisYear'] ?? 0.0).toDouble(),
      communityLikes: map['communityLikes'] ?? 0,
      sharedTrips: map['sharedTrips'] ?? 0,
      favoriteTransportMode: map['favoriteTransportMode'] ?? '',
      visitedCountries: List<String>.from(map['visitedCountries'] ?? []),
      visitedStates: List<String>.from(map['visitedStates'] ?? []),
    );
  }

  /// Convert UserStats to map
  Map<String, dynamic> toMap() {
    return {
      'tripsThisMonth': tripsThisMonth,
      'tripsThisYear': tripsThisYear,
      'distanceThisMonth': distanceThisMonth,
      'distanceThisYear': distanceThisYear,
      'communityLikes': communityLikes,
      'sharedTrips': sharedTrips,
      'favoriteTransportMode': favoriteTransportMode,
      'visitedCountries': visitedCountries,
      'visitedStates': visitedStates,
    };
  }

  /// Create a copy of UserStats with updated fields
  UserStats copyWith({
    int? tripsThisMonth,
    int? tripsThisYear,
    double? distanceThisMonth,
    double? distanceThisYear,
    int? communityLikes,
    int? sharedTrips,
    String? favoriteTransportMode,
    List<String>? visitedCountries,
    List<String>? visitedStates,
  }) {
    return UserStats(
      tripsThisMonth: tripsThisMonth ?? this.tripsThisMonth,
      tripsThisYear: tripsThisYear ?? this.tripsThisYear,
      distanceThisMonth: distanceThisMonth ?? this.distanceThisMonth,
      distanceThisYear: distanceThisYear ?? this.distanceThisYear,
      communityLikes: communityLikes ?? this.communityLikes,
      sharedTrips: sharedTrips ?? this.sharedTrips,
      favoriteTransportMode: favoriteTransportMode ?? this.favoriteTransportMode,
      visitedCountries: visitedCountries ?? this.visitedCountries,
      visitedStates: visitedStates ?? this.visitedStates,
    );
  }
}