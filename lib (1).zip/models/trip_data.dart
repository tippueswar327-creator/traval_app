class TripData {
  final String tripNumber;
  final String origin;
  final String destination;
  final DateTime? departureTime;
  final DateTime? arrivalTime;
  final String travelMode;
  final String purpose;
  final int numberOfTravelers;
  final String additionalNotes;

  TripData({
    required this.tripNumber,
    required this.origin,
    required this.destination,
    this.departureTime,
    this.arrivalTime,
    required this.travelMode,
    required this.purpose,
    required this.numberOfTravelers,
    required this.additionalNotes,
  });

  TripData copyWith({
    String? tripNumber,
    String? origin,
    String? destination,
    DateTime? departureTime,
    DateTime? arrivalTime,
    String? travelMode,
    String? purpose,
    int? numberOfTravelers,
    String? additionalNotes,
  }) {
    return TripData(
      tripNumber: tripNumber ?? this.tripNumber,
      origin: origin ?? this.origin,
      destination: destination ?? this.destination,
      departureTime: departureTime ?? this.departureTime,
      arrivalTime: arrivalTime ?? this.arrivalTime,
      travelMode: travelMode ?? this.travelMode,
      purpose: purpose ?? this.purpose,
      numberOfTravelers: numberOfTravelers ?? this.numberOfTravelers,
      additionalNotes: additionalNotes ?? this.additionalNotes,
    );
  }
}

class Traveler {
  final String id;
  final String ageGroup;
  final String gender;
  final String relation;

  Traveler({
    required this.id,
    required this.ageGroup,
    required this.gender,
    required this.relation,
  });

  Traveler copyWith({
    String? id,
    String? ageGroup,
    String? gender,
    String? relation,
  }) {
    return Traveler(
      id: id ?? this.id,
      ageGroup: ageGroup ?? this.ageGroup,
      gender: gender ?? this.gender,
      relation: relation ?? this.relation,
    );
  }
}