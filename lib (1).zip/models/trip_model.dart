import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

/// Trip model for managing trip data and information
class TripModel {
  final String id;
  final String userId;
  final String title;
  final String description;
  final DateTime startDate;
  final DateTime? endDate;
  final LatLng startLocation;
  final LatLng? endLocation;
  final List<TripStop> stops;
  final List<TripExpense> expenses;
  final double totalDistance;
  final Duration? totalDuration;
  final TransportMode transportMode;
  final List<String> photos;
  final bool isPublic;
  final int likes;
  final List<String> likedBy;
  final DateTime createdAt;
  final DateTime updatedAt;
  final TripStatus status;
  final Map<String, dynamic> metadata;

  TripModel({
    required this.id,
    required this.userId,
    required this.title,
    this.description = '',
    required this.startDate,
    this.endDate,
    required this.startLocation,
    this.endLocation,
    this.stops = const [],
    this.expenses = const [],
    this.totalDistance = 0.0,
    this.totalDuration,
    required this.transportMode,
    this.photos = const [],
    this.isPublic = false,
    this.likes = 0,
    this.likedBy = const [],
    required this.createdAt,
    required this.updatedAt,
    this.status = TripStatus.planned,
    this.metadata = const {},
  });

  /// Create TripModel from Firestore document
  factory TripModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    
    return TripModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      startDate: (data['startDate'] as Timestamp).toDate(),
      endDate: data['endDate'] != null 
          ? (data['endDate'] as Timestamp).toDate()
          : null,
      startLocation: LatLng(
        data['startLocation']['latitude'],
        data['startLocation']['longitude'],
      ),
      endLocation: data['endLocation'] != null
          ? LatLng(
              data['endLocation']['latitude'],
              data['endLocation']['longitude'],
            )
          : null,
      stops: (data['stops'] as List<dynamic>?)
          ?.map((stop) => TripStop.fromMap(stop))
          .toList() ?? [],
      expenses: (data['expenses'] as List<dynamic>?)
          ?.map((expense) => TripExpense.fromMap(expense))
          .toList() ?? [],
      totalDistance: (data['totalDistance'] ?? 0.0).toDouble(),
      totalDuration: data['totalDurationMinutes'] != null
          ? Duration(minutes: data['totalDurationMinutes'])
          : null,
      transportMode: TransportMode.values.firstWhere(
        (mode) => mode.name == data['transportMode'],
        orElse: () => TransportMode.car,
      ),
      photos: List<String>.from(data['photos'] ?? []),
      isPublic: data['isPublic'] ?? false,
      likes: data['likes'] ?? 0,
      likedBy: List<String>.from(data['likedBy'] ?? []),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
      status: TripStatus.values.firstWhere(
        (status) => status.name == data['status'],
        orElse: () => TripStatus.planned,
      ),
      metadata: Map<String, dynamic>.from(data['metadata'] ?? {}),
    );
  }

  /// Convert TripModel to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'title': title,
      'description': description,
      'startDate': Timestamp.fromDate(startDate),
      'endDate': endDate != null ? Timestamp.fromDate(endDate!) : null,
      'startLocation': {
        'latitude': startLocation.latitude,
        'longitude': startLocation.longitude,
      },
      'endLocation': endLocation != null
          ? {
              'latitude': endLocation!.latitude,
              'longitude': endLocation!.longitude,
            }
          : null,
      'stops': stops.map((stop) => stop.toMap()).toList(),
      'expenses': expenses.map((expense) => expense.toMap()).toList(),
      'totalDistance': totalDistance,
      'totalDurationMinutes': totalDuration?.inMinutes,
      'transportMode': transportMode.name,
      'photos': photos,
      'isPublic': isPublic,
      'likes': likes,
      'likedBy': likedBy,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'status': status.name,
      'metadata': metadata,
    };
  }

  /// Create a copy of TripModel with updated fields
  TripModel copyWith({
    String? title,
    String? description,
    DateTime? startDate,
    DateTime? endDate,
    LatLng? startLocation,
    LatLng? endLocation,
    List<TripStop>? stops,
    List<TripExpense>? expenses,
    double? totalDistance,
    Duration? totalDuration,
    TransportMode? transportMode,
    List<String>? photos,
    bool? isPublic,
    int? likes,
    List<String>? likedBy,
    DateTime? updatedAt,
    TripStatus? status,
    Map<String, dynamic>? metadata,
  }) {
    return TripModel(
      id: id,
      userId: userId,
      title: title ?? this.title,
      description: description ?? this.description,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      startLocation: startLocation ?? this.startLocation,
      endLocation: endLocation ?? this.endLocation,
      stops: stops ?? this.stops,
      expenses: expenses ?? this.expenses,
      totalDistance: totalDistance ?? this.totalDistance,
      totalDuration: totalDuration ?? this.totalDuration,
      transportMode: transportMode ?? this.transportMode,
      photos: photos ?? this.photos,
      isPublic: isPublic ?? this.isPublic,
      likes: likes ?? this.likes,
      likedBy: likedBy ?? this.likedBy,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      status: status ?? this.status,
      metadata: metadata ?? this.metadata,
    );
  }

  /// Get total expenses amount
  double get totalExpenses {
    return expenses.fold(0.0, (sum, expense) => sum + expense.amount);
  }

  /// Get formatted duration string
  String get formattedDuration {
    if (totalDuration == null) return '--';
    
    final hours = totalDuration!.inHours;
    final minutes = totalDuration!.inMinutes % 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    } else {
      return '${minutes}m';
    }
  }

  /// Get formatted distance string
  String get formattedDistance {
    if (totalDistance < 1) {
      return '${(totalDistance * 1000).toInt()}m';
    } else {
      return '${totalDistance.toStringAsFixed(1)}km';
    }
  }
}

/// Trip stop model for intermediate stops during a trip
class TripStop {
  final String id;
  final String name;
  final String? description;
  final LatLng location;
  final DateTime? arrivalTime;
  final DateTime? departureTime;
  final List<String> photos;
  final double? rating;
  final String? notes;

  TripStop({
    required this.id,
    required this.name,
    this.description,
    required this.location,
    this.arrivalTime,
    this.departureTime,
    this.photos = const [],
    this.rating,
    this.notes,
  });

  /// Create TripStop from map
  factory TripStop.fromMap(Map<String, dynamic> map) {
    return TripStop(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      description: map['description'],
      location: LatLng(
        map['location']['latitude'],
        map['location']['longitude'],
      ),
      arrivalTime: map['arrivalTime'] != null
          ? (map['arrivalTime'] as Timestamp).toDate()
          : null,
      departureTime: map['departureTime'] != null
          ? (map['departureTime'] as Timestamp).toDate()
          : null,
      photos: List<String>.from(map['photos'] ?? []),
      rating: map['rating']?.toDouble(),
      notes: map['notes'],
    );
  }

  /// Convert TripStop to map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'location': {
        'latitude': location.latitude,
        'longitude': location.longitude,
      },
      'arrivalTime': arrivalTime != null
          ? Timestamp.fromDate(arrivalTime!)
          : null,
      'departureTime': departureTime != null
          ? Timestamp.fromDate(departureTime!)
          : null,
      'photos': photos,
      'rating': rating,
      'notes': notes,
    };
  }
}

/// Trip expense model for tracking trip costs
class TripExpense {
  final String id;
  final String category;
  final String description;
  final double amount;
  final String currency;
  final DateTime date;
  final String? receipt;

  TripExpense({
    required this.id,
    required this.category,
    required this.description,
    required this.amount,
    this.currency = 'USD',
    required this.date,
    this.receipt,
  });

  /// Create TripExpense from map
  factory TripExpense.fromMap(Map<String, dynamic> map) {
    return TripExpense(
      id: map['id'] ?? '',
      category: map['category'] ?? '',
      description: map['description'] ?? '',
      amount: (map['amount'] ?? 0.0).toDouble(),
      currency: map['currency'] ?? 'USD',
      date: (map['date'] as Timestamp).toDate(),
      receipt: map['receipt'],
    );
  }

  /// Convert TripExpense to map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category': category,
      'description': description,
      'amount': amount,
      'currency': currency,
      'date': Timestamp.fromDate(date),
      'receipt': receipt,
    };
  }
}

/// Transport mode enumeration
enum TransportMode {
  car('🚗', 'Car'),
  bus('🚌', 'Bus'),
  train('🚆', 'Train'),
  plane('✈️', 'Plane'),
  bike('🚲', 'Bike'),
  walk('🚶', 'Walk'),
  motorcycle('🏍️', 'Motorcycle'),
  boat('⛵', 'Boat'),
  other('📍', 'Other');

  const TransportMode(this.icon, this.displayName);
  
  final String icon;
  final String displayName;
}

/// Trip status enumeration
enum TripStatus {
  planned('Planned'),
  ongoing('Ongoing'),
  completed('Completed'),
  cancelled('Cancelled');

  const TripStatus(this.displayName);
  
  final String displayName;
}