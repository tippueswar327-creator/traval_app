import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/trip_model.dart';
import '../utils/constants.dart';

/// Offline service for managing local data storage and synchronization
class OfflineService extends ChangeNotifier {
  late Box<Map> _offlineTripsBox;
  late Box<Map> _userPrefsBox;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  bool _isInitialized = false;
  bool _isOnline = true;
  List<String> _tripsToDelete = [];
  List<TripModel> _offlineTrips = [];

  // Getters
  bool get isInitialized => _isInitialized;
  bool get isOnline => _isOnline;
  List<TripModel> get offlineTrips => _offlineTrips;

  /// Initialize offline service and connectivity monitoring
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Open Hive boxes for local storage
      _offlineTripsBox = await Hive.openBox<Map>(AppConfig.offlineTripsBox);
      _userPrefsBox = await Hive.openBox<Map>(AppConfig.userPrefsBox);

      // Load offline trips from local storage
      await _loadOfflineTrips();

      // Load trips marked for deletion
      _tripsToDelete = _userPrefsBox.get('tripsToDelete', defaultValue: <String>[])?.cast<String>() ?? [];

      // Monitor connectivity changes
      Connectivity().onConnectivityChanged.listen(_onConnectivityChanged);
      
      // Check initial connectivity
      final connectivityResult = await Connectivity().checkConnectivity();
      _isOnline = connectivityResult != ConnectivityResult.none;

      _isInitialized = true;
      notifyListeners();

      // Sync if online
      if (_isOnline) {
        await syncOfflineTrips();
      }
    } catch (e) {
      debugPrint('Error initializing offline service: $e');
    }
  }

  /// Handle connectivity changes
  void _onConnectivityChanged(ConnectivityResult result) async {
    final wasOffline = !_isOnline;
    _isOnline = result != ConnectivityResult.none;
    
    notifyListeners();

    // If we just came back online, sync offline data
    if (wasOffline && _isOnline) {
      await syncOfflineTrips();
    }
  }

  /// Load offline trips from local storage
  Future<void> _loadOfflineTrips() async {
    try {
      final tripsData = _offlineTripsBox.values.toList();
      _offlineTrips = tripsData
          .map((tripMap) => _tripFromMap(Map<String, dynamic>.from(tripMap)))
          .toList();
      
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading offline trips: $e');
    }
  }

  /// Save trip to local storage
  Future<void> saveTrip(TripModel trip) async {
    try {
      await _offlineTripsBox.put(trip.id, _tripToMap(trip));
      
      // Update local list
      final existingIndex = _offlineTrips.indexWhere((t) => t.id == trip.id);
      if (existingIndex != -1) {
        _offlineTrips[existingIndex] = trip;
      } else {
        _offlineTrips.add(trip);
      }
      
      notifyListeners();
    } catch (e) {
      debugPrint('Error saving trip offline: $e');
    }
  }

  /// Delete trip from local storage
  Future<void> deleteTripLocal(String tripId) async {
    try {
      await _offlineTripsBox.delete(tripId);
      _offlineTrips.removeWhere((trip) => trip.id == tripId);
      notifyListeners();
    } catch (e) {
      debugPrint('Error deleting trip locally: $e');
    }
  }

  /// Mark trip for deletion when back online
  Future<void> markTripForDeletion(String tripId) async {
    try {
      _tripsToDelete.add(tripId);
      await _userPrefsBox.put('tripsToDelete', _tripsToDelete);
      
      // Remove from local storage immediately
      await deleteTripLocal(tripId);
    } catch (e) {
      debugPrint('Error marking trip for deletion: $e');
    }
  }

  /// Get all offline trips
  List<TripModel> getAllOfflineTrips() {
    return List.from(_offlineTrips);
  }

  /// Get offline trip by ID
  TripModel? getOfflineTripById(String tripId) {
    try {
      return _offlineTrips.firstWhere((trip) => trip.id == tripId);
    } catch (e) {
      return null;
    }
  }

  /// Check if trip exists offline
  bool hasOfflineTrip(String tripId) {
    return _offlineTrips.any((trip) => trip.id == tripId);
  }

  /// Sync offline trips with Firestore when back online
  Future<void> syncOfflineTrips() async {
    if (!_isOnline || !_isInitialized) return;

    try {
      // Sync trips marked for deletion
      await _syncDeletedTrips();

      // Sync offline trips to Firestore
      await _syncOfflineTripsToFirestore();

      debugPrint('Offline sync completed successfully');
    } catch (e) {
      debugPrint('Error syncing offline trips: $e');
    }
  }

  /// Sync trips marked for deletion
  Future<void> _syncDeletedTrips() async {
    for (final tripId in _tripsToDelete) {
      try {
        await _firestore
            .collection(AppConfig.tripsCollection)
            .doc(tripId)
            .delete();
        debugPrint('Deleted trip $tripId from Firestore');
      } catch (e) {
        debugPrint('Error deleting trip $tripId: $e');
      }
    }

    // Clear the deletion list
    _tripsToDelete.clear();
    await _userPrefsBox.put('tripsToDelete', _tripsToDelete);
  }

  /// Sync offline trips to Firestore
  Future<void> _syncOfflineTripsToFirestore() async {
    final tripsToSync = List<TripModel>.from(_offlineTrips);

    for (final trip in tripsToSync) {
      try {
        // Check if trip exists in Firestore
        final doc = await _firestore
            .collection(AppConfig.tripsCollection)
            .doc(trip.id)
            .get();

        if (doc.exists) {
          // Update existing trip
          await _firestore
              .collection(AppConfig.tripsCollection)
              .doc(trip.id)
              .update(trip.toFirestore());
        } else {
          // Create new trip
          await _firestore
              .collection(AppConfig.tripsCollection)
              .doc(trip.id)
              .set(trip.toFirestore());
        }

        // Remove from offline storage after successful sync
        await deleteTripLocal(trip.id);
        debugPrint('Synced trip ${trip.id} to Firestore');
      } catch (e) {
        debugPrint('Error syncing trip ${trip.id}: $e');
      }
    }
  }

  /// Save user preference
  Future<void> saveUserPreference(String key, dynamic value) async {
    try {
      await _userPrefsBox.put(key, value);
    } catch (e) {
      debugPrint('Error saving user preference: $e');
    }
  }

  /// Get user preference
  T? getUserPreference<T>(String key, {T? defaultValue}) {
    try {
      return _userPrefsBox.get(key, defaultValue: defaultValue) as T?;
    } catch (e) {
      debugPrint('Error getting user preference: $e');
      return defaultValue;
    }
  }

  /// Clear all offline data
  Future<void> clearOfflineData() async {
    try {
      await _offlineTripsBox.clear();
      await _userPrefsBox.clear();
      _offlineTrips.clear();
      _tripsToDelete.clear();
      notifyListeners();
    } catch (e) {
      debugPrint('Error clearing offline data: $e');
    }
  }

  /// Convert TripModel to Map for Hive storage
  Map<String, dynamic> _tripToMap(TripModel trip) {
    return {
      'id': trip.id,
      'userId': trip.userId,
      'title': trip.title,
      'description': trip.description,
      'startDate': trip.startDate.millisecondsSinceEpoch,
      'endDate': trip.endDate?.millisecondsSinceEpoch,
      'startLocationLat': trip.startLocation.latitude,
      'startLocationLng': trip.startLocation.longitude,
      'endLocationLat': trip.endLocation?.latitude,
      'endLocationLng': trip.endLocation?.longitude,
      'stops': trip.stops.map((stop) => {
        'id': stop.id,
        'name': stop.name,
        'description': stop.description,
        'locationLat': stop.location.latitude,
        'locationLng': stop.location.longitude,
        'arrivalTime': stop.arrivalTime?.millisecondsSinceEpoch,
        'departureTime': stop.departureTime?.millisecondsSinceEpoch,
        'photos': stop.photos,
        'rating': stop.rating,
        'notes': stop.notes,
      }).toList(),
      'expenses': trip.expenses.map((expense) => {
        'id': expense.id,
        'category': expense.category,
        'description': expense.description,
        'amount': expense.amount,
        'currency': expense.currency,
        'date': expense.date.millisecondsSinceEpoch,
        'receipt': expense.receipt,
      }).toList(),
      'totalDistance': trip.totalDistance,
      'totalDurationMinutes': trip.totalDuration?.inMinutes,
      'transportMode': trip.transportMode.name,
      'photos': trip.photos,
      'isPublic': trip.isPublic,
      'likes': trip.likes,
      'likedBy': trip.likedBy,
      'createdAt': trip.createdAt.millisecondsSinceEpoch,
      'updatedAt': trip.updatedAt.millisecondsSinceEpoch,
      'status': trip.status.name,
      'metadata': trip.metadata,
    };
  }

  /// Convert Map to TripModel for Hive storage
  TripModel _tripFromMap(Map<String, dynamic> map) {
    return TripModel(
      id: map['id'],
      userId: map['userId'],
      title: map['title'],
      description: map['description'] ?? '',
      startDate: DateTime.fromMillisecondsSinceEpoch(map['startDate']),
      endDate: map['endDate'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['endDate'])
          : null,
      startLocation: LatLng(map['startLocationLat'], map['startLocationLng']),
      endLocation: map['endLocationLat'] != null && map['endLocationLng'] != null
          ? LatLng(map['endLocationLat'], map['endLocationLng'])
          : null,
      stops: (map['stops'] as List<dynamic>?)?.map((stopMap) => TripStop(
        id: stopMap['id'],
        name: stopMap['name'],
        description: stopMap['description'],
        location: LatLng(stopMap['locationLat'], stopMap['locationLng']),
        arrivalTime: stopMap['arrivalTime'] != null
            ? DateTime.fromMillisecondsSinceEpoch(stopMap['arrivalTime'])
            : null,
        departureTime: stopMap['departureTime'] != null
            ? DateTime.fromMillisecondsSinceEpoch(stopMap['departureTime'])
            : null,
        photos: List<String>.from(stopMap['photos'] ?? []),
        rating: stopMap['rating']?.toDouble(),
        notes: stopMap['notes'],
      )).toList() ?? [],
      expenses: (map['expenses'] as List<dynamic>?)?.map((expenseMap) => TripExpense(
        id: expenseMap['id'],
        category: expenseMap['category'],
        description: expenseMap['description'],
        amount: expenseMap['amount'].toDouble(),
        currency: expenseMap['currency'] ?? 'USD',
        date: DateTime.fromMillisecondsSinceEpoch(expenseMap['date']),
        receipt: expenseMap['receipt'],
      )).toList() ?? [],
      totalDistance: map['totalDistance']?.toDouble() ?? 0.0,
      totalDuration: map['totalDurationMinutes'] != null
          ? Duration(minutes: map['totalDurationMinutes'])
          : null,
      transportMode: TransportMode.values.firstWhere(
        (mode) => mode.name == map['transportMode'],
        orElse: () => TransportMode.car,
      ),
      photos: List<String>.from(map['photos'] ?? []),
      isPublic: map['isPublic'] ?? false,
      likes: map['likes'] ?? 0,
      likedBy: List<String>.from(map['likedBy'] ?? []),
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updatedAt']),
      status: TripStatus.values.firstWhere(
        (status) => status.name == map['status'],
        orElse: () => TripStatus.planned,
      ),
      metadata: Map<String, dynamic>.from(map['metadata'] ?? {}),
    );
  }

  /// Dispose resources
  @override
  void dispose() {
    _offlineTripsBox.close();
    _userPrefsBox.close();
    super.dispose();
  }
}