import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import '../models/trip_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';
import 'offline_service.dart';

/// Trip service for managing trip CRUD operations and Google Maps integration
class TripService extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final OfflineService _offlineService = OfflineService();
  final Uuid _uuid = const Uuid();

  List<TripModel> _userTrips = [];
  List<TripModel> _communityTrips = [];
  TripModel? _currentTrip;
  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  List<TripModel> get userTrips => _userTrips;
  List<TripModel> get communityTrips => _communityTrips;
  TripModel? get currentTrip => _currentTrip;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  /// Load user's trips from Firestore
  Future<void> loadUserTrips(String userId) async {
    _setLoading(true);
    _clearError();

    try {
      final querySnapshot = await _firestore
          .collection(AppConfig.tripsCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _userTrips = querySnapshot.docs
          .map((doc) => TripModel.fromFirestore(doc))
          .toList();

      notifyListeners();
    } catch (e) {
      _setError('Failed to load trips. Please try again.');
      debugPrint('Error loading user trips: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Load community trips from Firestore
  Future<void> loadCommunityTrips() async {
    _setLoading(true);
    _clearError();

    try {
      final querySnapshot = await _firestore
          .collection(AppConfig.tripsCollection)
          .where('isPublic', isEqualTo: true)
          .orderBy('likes', descending: true)
          .limit(50)
          .get();

      _communityTrips = querySnapshot.docs
          .map((doc) => TripModel.fromFirestore(doc))
          .toList();

      notifyListeners();
    } catch (e) {
      _setError('Failed to load community trips. Please try again.');
      debugPrint('Error loading community trips: $e');
    } finally {
      _setLoading(false);
    }
  }

  /// Create a new trip
  Future<TripModel?> createTrip({
    required String userId,
    required String title,
    String description = '',
    required DateTime startDate,
    required LatLng startLocation,
    required TransportMode transportMode,
    bool isPublic = false,
  }) async {
    _setLoading(true);
    _clearError();

    try {
      final tripId = _uuid.v4();
      final now = DateTime.now();

      final trip = TripModel(
        id: tripId,
        userId: userId,
        title: title,
        description: description,
        startDate: startDate,
        startLocation: startLocation,
        transportMode: transportMode,
        isPublic: isPublic,
        createdAt: now,
        updatedAt: now,
        status: TripStatus.planned,
      );

      // Try to save to Firestore first
      try {
        await _firestore
            .collection(AppConfig.tripsCollection)
            .doc(tripId)
            .set(trip.toFirestore());
      } catch (e) {
        // If offline, save to local storage
        await _offlineService.saveTrip(trip);
      }

      // Add to local list
      _userTrips.insert(0, trip);
      _currentTrip = trip;
      
      notifyListeners();
      return trip;
    } catch (e) {
      _setError('Failed to create trip. Please try again.');
      debugPrint('Error creating trip: $e');
      return null;
    } finally {
      _setLoading(false);
    }
  }

  /// Update an existing trip
  Future<bool> updateTrip(TripModel trip) async {
    _setLoading(true);
    _clearError();

    try {
      final updatedTrip = trip.copyWith(
        updatedAt: DateTime.now(),
      );

      // Try to update in Firestore first
      try {
        await _firestore
            .collection(AppConfig.tripsCollection)
            .doc(trip.id)
            .update(updatedTrip.toFirestore());
      } catch (e) {
        // If offline, save to local storage
        await _offlineService.saveTrip(updatedTrip);
      }

      // Update local list
      final index = _userTrips.indexWhere((t) => t.id == trip.id);
      if (index != -1) {
        _userTriips[index] = updatedTrip;
      }

      if (_currentTrip?.id == trip.id) {
        _currentTrip = updatedTrip;
      }

      notifyListeners();
      return true;
    } catch (e) {
      _setError('Failed to update trip. Please try again.');
      debugPrint('Error updating trip: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Delete a trip
  Future<bool> deleteTrip(String tripId) async {
    _setLoading(true);
    _clearError();

    try {
      // Try to delete from Firestore first
      try {
        await _firestore
            .collection(AppConfig.tripsCollection)
            .doc(tripId)
            .delete();
      } catch (e) {
        // If offline, mark for deletion in local storage
        await _offlineService.markTripForDeletion(tripId);
      }

      // Remove from local list
      _userTrips.removeWhere((trip) => trip.id == tripId);
      
      if (_currentTrip?.id == tripId) {
        _currentTrip = null;
      }

      notifyListeners();
      return true;
    } catch (e) {
      _setError('Failed to delete trip. Please try again.');
      debugPrint('Error deleting trip: $e');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Start a trip (change status to ongoing)
  Future<bool> startTrip(String tripId) async {
    final trip = _userTrips.firstWhere((t) => t.id == tripId);
    final updatedTrip = trip.copyWith(
      status: TripStatus.ongoing,
      startDate: DateTime.now(),
    );
    
    return await updateTrip(updatedTrip);
  }

  /// End a trip (change status to completed)
  Future<bool> endTrip(String tripId, {LatLng? endLocation}) async {
    final trip = _userTrips.firstWhere((t) => t.id == tripId);
    
    // Calculate total distance and duration if end location is provided
    double totalDistance = trip.totalDistance;
    Duration? totalDuration = trip.totalDuration;
    
    if (endLocation != null) {
      totalDistance = await _calculateDistance(trip.startLocation, endLocation);
      totalDuration = DateTime.now().difference(trip.startDate);
    }

    final updatedTrip = trip.copyWith(
      status: TripStatus.completed,
      endDate: DateTime.now(),
      endLocation: endLocation,
      totalDistance: totalDistance,
      totalDuration: totalDuration,
    );
    
    return await updateTrip(updatedTrip);
  }

  /// Add a stop to a trip
  Future<bool> addTripStop({
    required String tripId,
    required String name,
    required LatLng location,
    String? description,
    DateTime? arrivalTime,
  }) async {
    final tripIndex = _userTrips.indexWhere((t) => t.id == tripId);
    if (tripIndex == -1) return false;

    final trip = _userTrips[tripIndex];
    final stopId = _uuid.v4();
    
    final newStop = TripStop(
      id: stopId,
      name: name,
      description: description,
      location: location,
      arrivalTime: arrivalTime ?? DateTime.now(),
    );

    final updatedStops = List<TripStop>.from(trip.stops)..add(newStop);
    final updatedTrip = trip.copyWith(stops: updatedStops);
    
    return await updateTrip(updatedTrip);
  }

  /// Add an expense to a trip
  Future<bool> addTripExpense({
    required String tripId,
    required String category,
    required String description,
    required double amount,
    String currency = 'USD',
    DateTime? date,
  }) async {
    final tripIndex = _userTrips.indexWhere((t) => t.id == tripId);
    if (tripIndex == -1) return false;

    final trip = _userTrips[tripIndex];
    final expenseId = _uuid.v4();
    
    final newExpense = TripExpense(
      id: expenseId,
      category: category,
      description: description,
      amount: amount,
      currency: currency,
      date: date ?? DateTime.now(),
    );

    final updatedExpenses = List<TripExpense>.from(trip.expenses)..add(newExpense);
    final updatedTrip = trip.copyWith(expenses: updatedExpenses);
    
    return await updateTrip(updatedTrip);
  }

  /// Like/unlike a community trip
  Future<bool> toggleTripLike(String tripId, String userId) async {
    try {
      final tripRef = _firestore
          .collection(AppConfig.tripsCollection)
          .doc(tripId);

      final doc = await tripRef.get();
      if (!doc.exists) return false;

      final trip = TripModel.fromFirestore(doc);
      final isLiked = trip.likedBy.contains(userId);
      
      List<String> updatedLikedBy = List.from(trip.likedBy);
      int updatedLikes = trip.likes;

      if (isLiked) {
        updatedLikedBy.remove(userId);
        updatedLikes = (updatedLikes - 1).clamp(0, double.infinity).toInt();
      } else {
        updatedLikedBy.add(userId);
        updatedLikes++;
      }

      await tripRef.update({
        'likes': updatedLikes,
        'likedBy': updatedLikedBy,
      });

      // Update local community trips list
      final communityIndex = _communityTrips.indexWhere((t) => t.id == tripId);
      if (communityIndex != -1) {
        _communityTrips[communityIndex] = _communityTrips[communityIndex].copyWith(
          likes: updatedLikes,
          likedBy: updatedLikedBy,
        );
        notifyListeners();
      }

      return true;
    } catch (e) {
      debugPrint('Error toggling trip like: $e');
      return false;
    }
  }

  /// Get current location
  Future<LatLng?> getCurrentLocation() async {
    try {
      // Check location permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return null;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return null;
      }

      // Get current position
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      return LatLng(position.latitude, position.longitude);
    } catch (e) {
      debugPrint('Error getting current location: $e');
      return null;
    }
  }

  /// Get address from coordinates
  Future<String> getAddressFromCoordinates(LatLng coordinates) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        coordinates.latitude,
        coordinates.longitude,
      );

      if (placemarks.isNotEmpty) {
        final placemark = placemarks.first;
        return '${placemark.name}, ${placemark.locality}, ${placemark.country}';
      }
      
      return 'Unknown location';
    } catch (e) {
      debugPrint('Error getting address: $e');
      return 'Unknown location';
    }
  }

  /// Get coordinates from address
  Future<LatLng?> getCoordinatesFromAddress(String address) async {
    try {
      final locations = await locationFromAddress(address);
      if (locations.isNotEmpty) {
        final location = locations.first;
        return LatLng(location.latitude, location.longitude);
      }
      return null;
    } catch (e) {
      debugPrint('Error getting coordinates: $e');
      return null;
    }
  }

  /// Calculate distance between two points
  Future<double> _calculateDistance(LatLng start, LatLng end) async {
    try {
      final distance = Geolocator.distanceBetween(
        start.latitude,
        start.longitude,
        end.latitude,
        end.longitude,
      );
      return distance / 1000; // Convert to kilometers
    } catch (e) {
      debugPrint('Error calculating distance: $e');
      return 0.0;
    }
  }

  /// Set current trip
  void setCurrentTrip(TripModel? trip) {
    _currentTrip = trip;
    notifyListeners();
  }

  /// Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  /// Set error message
  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  /// Clear error message
  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  /// Sync offline trips when back online
  Future<void> syncOfflineTrips() async {
    await _offlineService.syncOfflineTrips();
    // Reload trips after sync
    // Note: userId should be passed from auth service
  }
}