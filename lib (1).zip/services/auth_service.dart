import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../models/user_model.dart';
import '../utils/constants.dart';

/// Authentication service for managing user login, registration, and profile
class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  User? _user;
  UserModel? _userModel;
  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  User? get user => _user;
  UserModel? get userModel => _userModel;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _user != null;

  /// Initialize auth service and listen to auth state changes
  AuthService() {
    _auth.authStateChanges().listen(_onAuthStateChanged);
  }

  /// Handle authentication state changes
  void _onAuthStateChanged(User? user) async {
    _user = user;
    
    if (user != null) {
      // Load user model from Firestore
      await _loadUserModel();
    } else {
      _userModel = null;
    }
    
    notifyListeners();
  }

  /// Load user model from Firestore
  Future<void> _loadUserModel() async {
    if (_user == null) return;

    try {
      final doc = await _firestore
          .collection(AppConfig.usersCollection)
          .doc(_user!.uid)
          .get();

      if (doc.exists) {
        _userModel = UserModel.fromFirestore(doc);
      } else {
        // Create new user model if doesn't exist
        await _createUserModel();
      }
    } catch (e) {
      debugPrint('Error loading user model: $e');
    }
  }

  /// Create new user model in Firestore
  Future<void> _createUserModel() async {
    if (_user == null) return;

    try {
      final newUser = UserModel(
        id: _user!.uid,
        email: _user!.email ?? '',
        displayName: _user!.displayName ?? 'User',
        photoUrl: _user!.photoURL,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        stats: UserStats(),
      );

      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(_user!.uid)
          .set(newUser.toFirestore());

      _userModel = newUser;
    } catch (e) {
      debugPrint('Error creating user model: $e');
    }
  }

  /// Sign in with email and password
  Future<bool> signInWithEmailPassword(String email, String password) async {
    _setLoading(true);
    _clearError();

    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      return credential.user != null;
    } on FirebaseAuthException catch (e) {
      _setError(_getErrorMessage(e));
      return false;
    } catch (e) {
      _setError('An unexpected error occurred. Please try again.');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Sign up with email and password
  Future<bool> signUpWithEmailPassword(
    String email,
    String password,
    String displayName,
  ) async {
    _setLoading(true);
    _clearError();

    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (credential.user != null) {
        // Update display name
        await credential.user!.updateDisplayName(displayName);
        await credential.user!.reload();
        
        return true;
      }
      return false;
    } on FirebaseAuthException catch (e) {
      _setError(_getErrorMessage(e));
      return false;
    } catch (e) {
      _setError('An unexpected error occurred. Please try again.');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Sign in with Google
  Future<bool> signInWithGoogle() async {
    _setLoading(true);
    _clearError();

    try {
      // Trigger the authentication flow
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      
      if (googleUser == null) {
        // User cancelled the sign-in
        _setLoading(false);
        return false;
      }

      // Obtain the auth details from the request
      final GoogleSignInAuthentication googleAuth = 
          await googleUser.authentication;

      // Create a new credential
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Sign in to Firebase with the Google credential
      final userCredential = await _auth.signInWithCredential(credential);
      
      return userCredential.user != null;
    } on FirebaseAuthException catch (e) {
      _setError(_getErrorMessage(e));
      return false;
    } catch (e) {
      _setError('Failed to sign in with Google. Please try again.');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      await Future.wait([
        _auth.signOut(),
        _googleSignIn.signOut(),
      ]);
    } catch (e) {
      debugPrint('Error signing out: $e');
    }
  }

  /// Send password reset email
  Future<bool> sendPasswordResetEmail(String email) async {
    _setLoading(true);
    _clearError();

    try {
      await _auth.sendPasswordResetEmail(email: email);
      return true;
    } on FirebaseAuthException catch (e) {
      _setError(_getErrorMessage(e));
      return false;
    } catch (e) {
      _setError('Failed to send password reset email. Please try again.');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Update user profile
  Future<bool> updateUserProfile({
    String? displayName,
    String? photoUrl,
  }) async {
    if (_user == null || _userModel == null) return false;

    _setLoading(true);
    _clearError();

    try {
      // Update Firebase Auth profile
      if (displayName != null) {
        await _user!.updateDisplayName(displayName);
      }
      if (photoUrl != null) {
        await _user!.updatePhotoURL(photoUrl);
      }
      await _user!.reload();

      // Update Firestore user model
      final updatedUser = _userModel!.copyWith(
        displayName: displayName ?? _userModel!.displayName,
        photoUrl: photoUrl ?? _userModel!.photoUrl,
        updatedAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(_user!.uid)
          .update(updatedUser.toFirestore());

      _userModel = updatedUser;
      notifyListeners();
      
      return true;
    } catch (e) {
      _setError('Failed to update profile. Please try again.');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  /// Update user achievements
  Future<void> updateUserAchievements(Map<String, bool> newAchievements) async {
    if (_userModel == null) return;

    try {
      final updatedAchievements = Map<String, bool>.from(_userModel!.achievements);
      updatedAchievements.addAll(newAchievements);

      final updatedUser = _userModel!.copyWith(
        achievements: updatedAchievements,
        updatedAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(_user!.uid)
          .update({'achievements': updatedAchievements});

      _userModel = updatedUser;
      notifyListeners();
    } catch (e) {
      debugPrint('Error updating achievements: $e');
    }
  }

  /// Update user stats
  Future<void> updateUserStats({
    int? totalTrips,
    double? totalDistance,
    UserStats? stats,
  }) async {
    if (_userModel == null) return;

    try {
      final updatedUser = _userModel!.copyWith(
        totalTrips: totalTrips ?? _userModel!.totalTrips,
        totalDistance: totalDistance ?? _userModel!.totalDistance,
        stats: stats ?? _userModel!.stats,
        updatedAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(_user!.uid)
          .update({
        'totalTrips': updatedUser.totalTrips,
        'totalDistance': updatedUser.totalDistance,
        'stats': updatedUser.stats.toMap(),
        'updatedAt': Timestamp.fromDate(updatedUser.updatedAt),
      });

      _userModel = updatedUser;
      notifyListeners();
    } catch (e) {
      debugPrint('Error updating user stats: $e');
    }
  }

  /// Set loading state
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  /// Set error message
  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  /// Clear error message
  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  /// Get user-friendly error message from FirebaseAuthException
  String _getErrorMessage(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'No user found with this email address.';
      case 'wrong-password':
        return 'Incorrect password. Please try again.';
      case 'email-already-in-use':
        return 'An account already exists with this email address.';
      case 'weak-password':
        return 'Password is too weak. Please choose a stronger password.';
      case 'invalid-email':
        return 'Please enter a valid email address.';
      case 'user-disabled':
        return 'This account has been disabled.';
      case 'too-many-requests':
        return 'Too many failed attempts. Please try again later.';
      case 'operation-not-allowed':
        return 'This sign-in method is not enabled.';
      default:
        return e.message ?? 'An error occurred. Please try again.';
    }
  }
}